package com.base.util;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Threads {
      public  static  final ExecutorService executorService = Executors.newFixedThreadPool(5);
}
