package com.base.sdk.attach;

public interface CustomAttachmentType {
    // 多端统一
    int Guess = 1;//猜拳
    int SnapChat = 2;
    int Sticker = 3;
    int RTS = 4;
}
