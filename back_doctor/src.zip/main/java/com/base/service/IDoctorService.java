package com.base.service;

import com.base.bean.Doctor;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 用户 服务类
 * </p>
 *
 * @author admin
 * @since 2023-08-15
 */
public interface IDoctorService extends IService<Doctor> {

}
