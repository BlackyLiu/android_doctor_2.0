package com.base.service;

import com.base.bean.Chat;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 聊天 服务类
 * </p>
 *
 * @author admin
 * @since 2023-08-11
 */
public interface IChatService extends IService<Chat> {

}
