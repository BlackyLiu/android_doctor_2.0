qiNiuDns = "cdn.godhero.xyz"

function getUrl(key){
	 return "http://"+qiNiuDns+"/"+key;
}